
import streamlit as st
import torch
from PIL import Image
import os
import numpy as np
from pathlib import Path
from yolov5.utils.general import non_max_suppression, scale_coords
from yolov5.utils.datasets import letterbox
from yolov5.models.common import DetectMultiBackend

st.set_page_config(page_title="AffoDent Dental Lesion Detector", layout="centered")

st.title("🦷 AffoDent Dental Lesion Detector")
st.markdown("Upload a dental image to detect caries, cavities, ulcers, and more using a YOLOv5 model.")

uploaded_file = st.file_uploader("Upload a dental image", type=["jpg", "jpeg", "png"])

if uploaded_file:
    image = Image.open(uploaded_file).convert("RGB")
    st.image(image, caption="Uploaded Image", use_column_width=True)

    model = DetectMultiBackend("best.pt", device="cpu", dnn=False)
    stride, names = model.stride, model.names

    img = np.array(image)
    img0 = img.copy()
    img = letterbox(img, 640, stride=stride, auto=True)[0]
    img = img.transpose((2, 0, 1))[::-1]
    img = np.ascontiguousarray(img)
    img = torch.from_numpy(img).to("cpu")
    img = img.float() / 255.0
    img = img.unsqueeze(0)

    pred = model(img, augment=False, visualize=False)
    pred = non_max_suppression(pred, 0.25, 0.45, None, False, max_det=1000)

    for det in pred:
        if len(det):
            det[:, :4] = scale_coords(img.shape[2:], det[:, :4], img0.shape).round()
            for *xyxy, conf, cls in reversed(det):
                label = f'{names[int(cls)]} {conf:.2f}'
                image_draw = Image.fromarray(img0)
                draw = ImageDraw.Draw(image_draw)
                draw.rectangle(xyxy, outline="red", width=3)
                draw.text((xyxy[0], xyxy[1]), label, fill="white")
            st.image(image_draw, caption="Detection Result", use_column_width=True)
        else:
            st.info("No findings detected.")
